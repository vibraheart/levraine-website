# LEVRAINE

Static corporate/brand website for **LEVRAINE**, operated by **Marship Vibraheart Inc.**

Designed for deployment on **Cloudflare Pages** with `levraine.com` registered at Namecheap.

## Before publishing

1. Replace every occurrence of `REPLACE_WITH_YOUR_EMAIL` with the real company contact email.
2. Add your own LEVRAINE images to `assets/` using these filenames:
   - `levraine-hero.jpg`
   - `levraine-product-1.jpg`
   - `levraine-product-2.jpg`
   - `levraine-product-3.jpg`
3. Confirm product claims and dimensions in `index.html` are current.
4. Review `privacy.html` and update the contact email there as well.

## Cloudflare Pages settings

This is a plain static site. No build command is required.

- Framework preset: **None**
- Build command: **leave blank**
- Build output directory: **/** (repository root)
- Root directory: **/**

See `DEPLOY_CLOUDFLARE.md` for the full Namecheap + Cloudflare setup.

## Local preview

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.
